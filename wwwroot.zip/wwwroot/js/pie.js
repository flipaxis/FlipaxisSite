jQuery(function($){
    
    let n = 0;

    $(".rating li").each(function() {
        let li = this;
        let rotVal = $(".val", li).text();
        rotVal = (rotVal / 100) * 360;
        
        if (rotVal > 270){
            $(li).addClass("q4");
        }
        else if (rotVal > 180){
            $(li).addClass("q3");
        }
        else if (rotVal > 90){
            $(li).addClass("q2");
        }
        else{
            $(li).addClass("q1");
        }
        
        
        let color = [
            "rgb(100, 100, 180)",
            "rgb(100, 180, 100)",
            "rgb(100, 180, 180)",
            "rgb(180, 100, 100)",
            "rgb(180, 100, 180)",
            "rgb(180, 180, 100)",
            "rgb(180, 180, 180)"
            // "rgb(100, 100, 100)"
        ];
        $(".quad", li).css({
            backgroundColor: color[n],
            borderColor: color[n],
        });
        
        $(".qm", li).css({
            transform: `rotate(${rotVal}deg)`,
        });
        
        n++;
        if (n > color.length - 1)
            n = 0;

    });
})
