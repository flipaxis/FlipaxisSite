$.noConflict();
jQuery(function($){


    $("#mobileMenuButton").click(function(){
        $("nav#title").toggleClass("activeMenu");
    })

    // $("#close").click(function(){
    //     $("nav#title").removeClass("activeMenu");
    // })

    // $("#menu a").click(function(){
    //     if ($("nav").css("display").toLowerCase() != "none")
    //         $("#menu").removeClass("show");
    // })
   

    $(window).resize(function () {
        if($(window).width() >= (768 - 20))
            $("nav#title").removeClass("activeMenu");
    })

    $("#lv1 li").mouseover(function () {
        half = $(window).height() / 2
        pos = $("nav#title").offset().top + ($("nav#title").height()/2) - $(document).scrollTop()
        if (pos > half)
        {
            $(".lv2").addClass("up")
            $(".lv2").removeClass("down")
        }
        else
        {
            $(".lv2").addClass("down")
            $(".lv2").removeClass("up")
        }
    })
})
